@echo off
setlocal EnableExtensions
title Desinstalar catalogo Auditoria de Cifras PEN
set "GUID={F9B45EFA-48C7-4EC0-8919-E2D858BD7A36}"
reg delete "HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\%GUID%" /f >nul 2>&1
echo Catalogo removido. Reinicie Word.
pause
